import React from 'react';
import { Route } from 'react-router-dom';
import RoleProtectedRoute from './RoleProtectedRoute';
import TelaPrestador from '../screens/Proprietario/Prestador/TelaPrestador';
import TelaImovel from '../screens/Proprietario/Imovel/TelaImovel';
import TelaPrincipal from '../screens/Proprietario/TelaPrincipal/TelaPrincipal';
import TelaAgendamento from '../screens/Proprietario/Agendamento/TelaAgendamento';
import TelaContratos from '../screens/Proprietario/Contratos/TelaContratos';
import SplashScreen from '../screens/Components/SplashScreen';
import TelaInquilino from '../screens/Proprietario/Inquilino/TelaInquilino';

const routes = [

  <Route
    key="splash-screen"
    path="/SplashScreen"
    element={<SplashScreen />}
  />,
  <Route
    key="tela-principal"
    path="/tela-principal"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaPrincipal />
        </div>
      </RoleProtectedRoute>
    }
  />,
  <Route
    key="agendamentos"
    path="/agendamentos"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaAgendamento />
        </div>
      </RoleProtectedRoute>
    }
  />,
  <Route
    key="contratos"
    path="/contratos"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaContratos />
        </div>
      </RoleProtectedRoute>
    }
  />,
    <Route
    key="imovel"
    path="/imovel"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaImovel />
        </div>
      </RoleProtectedRoute>
    }
  />,
  <Route
    key="inquilino"
    path="/inquilino"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaInquilino />
        </div>
      </RoleProtectedRoute>
    }
  />,
  <Route
    key="prestadores"
    path="/prestadores"
    element={
      <RoleProtectedRoute allowedRoles={['PROPRIETARIO']}>
        <div style={{ display: 'flex' }}>
          <TelaPrestador />
        </div>
      </RoleProtectedRoute>
    }
  />

];

export default routes;

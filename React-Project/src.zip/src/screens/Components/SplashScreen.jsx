import React from 'react';
import './SplashScreen.css'; // Estilos da splash

export default function SplashScreen() {

  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/tela-principal');
    }, 2000); // 2 segundos de splash

    return () => clearTimeout(timer);
  }, [navigate]);

  
  return (
  <div class="splash-container">
    <img src="slpash_logo.png" alt="Logo" class="splash-logo" />
    
  </div>
  );
}
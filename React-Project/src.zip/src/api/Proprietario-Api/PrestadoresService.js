import axios from 'axios';

const ESPECIALIDADE = 'http://localhost:8080/enums/especialidade-prestador';

export const listarEspecialidade = async () => {
  const token = localStorage.getItem('token');

  const response = await axios.get(ESPECIALIDADE, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  return response.data;
};
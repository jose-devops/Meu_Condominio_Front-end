import axios from 'axios';

const BASE_URL = 'http://localhost:8080/auth';  // Atualizamos para a URL correta

export const login = async (email, senha, tipo) => {
  // Escolher a rota de login com base no tipo (Morador ou Proprietário)
  const loginUrl = tipo === 'MORADOR' ? `${BASE_URL}/login-morador` : `${BASE_URL}/login-proprietario`;

  try {
    // Realiza a requisição de login para a rota correta
    const response = await axios.post(loginUrl, {
      email,
      senha
    });

    // Recupera o token da resposta
    const token = response.data.token;

    // Se o token for retornado, armazene no localStorage
    if (token) {
      localStorage.setItem('token', token); 
    }

    return token;
  } catch (error) {
    console.error('Erro ao realizar o login:', error);
    throw new Error('Login falhou! Verifique suas credenciais.');
  }
};

export const logout = () => {
  localStorage.removeItem('token');  // Remove o token do localStorage ao fazer logout
};
